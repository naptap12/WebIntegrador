/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author renzo
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ConexionBD {

    private final String driver = "com.mysql.jdbc.Driver";
    private final String database = "tiendadonpepe";
    private final String hostname = "localhost";
    private final String port = "3306";
    private final String username = "root";
    private final String password = "admin";

    public Connection conectarBD() {
        String url = "jdbc:mysql://" + hostname + ":" + port + "/" + database + "?useSSL=false";
        Connection conn;

        try {
            Class.forName(driver);
            conn = DriverManager.getConnection(url, username, password);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return null;
        }
        return conn;
    }

    public void cerrarconexionsql(Connection conn) {
        try {
            conn.close();
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }
}
